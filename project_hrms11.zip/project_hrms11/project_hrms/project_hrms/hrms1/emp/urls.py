from django.urls import path
from . import views

urlpatterns = [
        path("emp_signup/", views.EmployeeAPI.as_view()),
        path('post_emergency/', views.emergency_contactAPI.as_view()),
        path("education_detail/", views.EmployeeEducationAPI.as_view()),
        path('get_employee/', views.getallemployeeDataAPI.as_view()),
        path('get_employee1/', views.getallemployeeAPI.as_view()),
        path('get_emp_emergency/', views.getemergencyDataAPI.as_view()), #error in this {"int() argument must be a string, a bytes-like object or a real number, not 'emp_personal'"
        path('get_emergency1/', views.getemp_emergencyAPI.as_view()),
        path("get_education_detail/", views.getallemployee_educationDataAPI.as_view()), #error in this
        path("update_emp/<employee_id>/", views.updateemployeedataAPI.as_view()),
        path("update_emergency/<employee_id>/", views.emergency_updatecontactAPI.as_view()),
        path("delete_emp/", views.delete_employeedataAPI.as_view()),
        # roshni
        path('post_data/', views.Experience1_Register.as_view()),  # Experience post
        path('get_data1/', views.Experience2.as_view()),  # single data get
        path('get_data2/', views.Experience3.as_view()),  # all data get
        path('put_data3/<employee_id>/', views.Experience4.as_view()), # Update data
        path('delete_data/<employee_id>/', views.delete_work.as_view())
]
